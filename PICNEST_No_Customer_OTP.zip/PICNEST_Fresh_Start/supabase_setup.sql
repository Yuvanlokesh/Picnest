-- PICNEST fresh Supabase setup
-- Run the complete script in Supabase Dashboard > SQL Editor > New query.
-- IMPORTANT: After running this script, add the admin phone in the final section below.

create extension if not exists pgcrypto;

create table if not exists public.picnest_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text not null,
  phone text not null unique,
  address text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.picnest_admins (
  phone text primary key,
  created_at timestamptz not null default now()
);

create table if not exists public.picnest_orders (
  id text primary key,
  user_id uuid,
  customer_name text not null,
  customer_phone text not null,
  delivery_address text not null,
  items jsonb not null default '[]'::jsonb,
  total numeric(12,2) not null check (total >= 0),
  status text not null default 'New',
  payment_status text not null default 'Pending',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.picnest_events (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  phone text not null,
  event_type text not null,
  event_date date,
  city_venue text,
  notes text,
  created_at timestamptz not null default now()
);

create index if not exists picnest_orders_user_created_idx on public.picnest_orders(user_id, created_at desc);
create index if not exists picnest_orders_created_idx on public.picnest_orders(created_at desc);
create index if not exists picnest_events_created_idx on public.picnest_events(created_at desc);

alter table public.picnest_profiles enable row level security;
alter table public.picnest_admins enable row level security;
alter table public.picnest_orders enable row level security;
alter table public.picnest_events enable row level security;

-- Guest checkout: customers do not create Supabase Auth accounts and do not use OTP.
-- Make user_id optional for guest orders and remove any old auth.users foreign key.
alter table public.picnest_orders alter column user_id drop not null;
alter table public.picnest_orders drop constraint if exists picnest_orders_user_id_fkey;

-- Remove old policies with these names so the setup can be safely re-run.
drop policy if exists "profile read own" on public.picnest_profiles;
drop policy if exists "profile insert own" on public.picnest_profiles;
drop policy if exists "profile update own" on public.picnest_profiles;
drop policy if exists "admins read own phone" on public.picnest_admins;
drop policy if exists "customer create own order" on public.picnest_orders;
drop policy if exists "public create guest order" on public.picnest_orders;
drop policy if exists "customer read own orders" on public.picnest_orders;
drop policy if exists "admins read all orders" on public.picnest_orders;
drop policy if exists "admins update all orders" on public.picnest_orders;
drop policy if exists "public create event enquiry" on public.picnest_events;
drop policy if exists "admins read event enquiries" on public.picnest_events;

create policy "profile read own" on public.picnest_profiles
for select to authenticated using (id = auth.uid());
create policy "profile insert own" on public.picnest_profiles
for insert to authenticated with check (id = auth.uid() and phone = (auth.jwt() ->> 'phone'));
create policy "profile update own" on public.picnest_profiles
for update to authenticated using (id = auth.uid()) with check (id = auth.uid() and phone = (auth.jwt() ->> 'phone'));

-- A logged-in user can only see the allowlist row matching their verified JWT phone.
create policy "admins read own phone" on public.picnest_admins
for select to authenticated using (phone = (auth.jwt() ->> 'phone'));

create policy "customer create own order" on public.picnest_orders
for insert to authenticated with check (user_id = auth.uid() and customer_phone = (auth.jwt() ->> 'phone'));

-- Public guest checkout. Customers can submit orders without creating an account or verifying OTP.
-- Public users can INSERT only; they cannot read, update, or delete customer orders.
create policy "public create guest order" on public.picnest_orders
for insert to anon, authenticated with check (
  user_id is null
  and length(trim(customer_name)) >= 2
  and length(regexp_replace(customer_phone, '[^0-9]', '', 'g')) >= 10
  and length(trim(delivery_address)) >= 8
  and total >= 0
);
create policy "customer read own orders" on public.picnest_orders
for select to authenticated using (user_id = auth.uid());
create policy "admins read all orders" on public.picnest_orders
for select to authenticated using (
  exists (select 1 from public.picnest_admins a where a.phone = (auth.jwt() ->> 'phone'))
);
create policy "admins update all orders" on public.picnest_orders
for update to authenticated using (
  exists (select 1 from public.picnest_admins a where a.phone = (auth.jwt() ->> 'phone'))
) with check (
  exists (select 1 from public.picnest_admins a where a.phone = (auth.jwt() ->> 'phone'))
);

-- Event form can accept enquiries without forcing customers to sign in.
-- Public users can INSERT only; reading is restricted to admins.
create policy "public create event enquiry" on public.picnest_events
for insert to anon, authenticated with check (
  length(trim(name)) >= 2 and length(regexp_replace(phone, '[^0-9]', '', 'g')) >= 10
);
create policy "admins read event enquiries" on public.picnest_events
for select to authenticated using (
  exists (select 1 from public.picnest_admins a where a.phone = (auth.jwt() ->> 'phone'))
);

-- Private storage for customer-uploaded photos. Never make this bucket public.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('picnest-photos', 'picnest-photos', false, 8388608, array['image/jpeg','image/png','image/webp','image/heic'])
on conflict (id) do update set public = false, file_size_limit = 8388608,
  allowed_mime_types = array['image/jpeg','image/png','image/webp','image/heic'];

drop policy if exists "customers upload own picnest photos" on storage.objects;
drop policy if exists "guest upload picnest photos" on storage.objects;
drop policy if exists "admins read picnest photos" on storage.objects;
create policy "customers upload own picnest photos" on storage.objects
for insert to authenticated with check (
  bucket_id = 'picnest-photos' and (storage.foldername(name))[1] = auth.uid()::text
);

-- Allow guest checkout photo uploads to the private bucket. The folder starts with a UUID guest ID.
-- The bucket retains an 8 MB per-file limit and image-only MIME allowlist above.
create policy "guest upload picnest photos" on storage.objects
for insert to anon with check (
  bucket_id = 'picnest-photos'
  and (storage.foldername(name))[1] ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
);
create policy "admins read picnest photos" on storage.objects
for select to authenticated using (
  bucket_id = 'picnest-photos' and exists (
    select 1 from public.picnest_admins a where a.phone = (auth.jwt() ->> 'phone')
  )
);

-- OPTIONAL: create your admin allowlist entry AFTER replacing the phone below.
-- Use international format, e.g. +919876543210. The separate admin dashboard still uses OTP login for security.
-- Uncomment and edit this line, then run it separately:
-- insert into public.picnest_admins(phone) values ('+91YOUR_ADMIN_MOBILE') on conflict (phone) do nothing;

-- Check setup:
select 'PICNEST guest checkout schema ready. Customer OTP removed. Configure SMS OTP only if you want to use the separate admin dashboard.' as setup_status;
