# PICNEST — Fresh website + Supabase setup

This folder contains:
- `index.html` — customer storefront, guest checkout (no OTP), photo uploads, cart, order placement and WhatsApp receipt to **+91 86818 01077**.
- `admin.html` — separate private admin login/dashboard for orders, customer photo links, payment status, fulfilment status and event enquiries.
- `supabase_setup.sql` — database tables, Row Level Security (RLS), private photo storage and policies.

## 1. Supabase connection
Both HTML files in this updated package are already configured with the Supabase Project URL and publishable key you provided. The publishable key is intended for browser use. Never use a `service_role` or secret key in either HTML file.

## 2. Create the database and secure photo storage
1. In Supabase, open **SQL Editor → New query**.
2. Paste the complete contents of `supabase_setup.sql` and click **Run**.
3. The script creates order and event tables, an admin allowlist, guest-checkout RLS policies and a **private** Storage bucket named `picnest-photos`. Customer details are saved in the customer browser; no customer auth profile is created.
4. Do not make the photo bucket public. Do not disable RLS.

## 3. Customer checkout without OTP

The customer storefront does not use Supabase Auth. Customers enter their name, mobile number and delivery address, then place orders without an OTP or password. Their details are saved in that browser for convenience. Orders and uploaded photos are submitted using the Supabase publishable key and the guest INSERT/upload policies in the SQL script.

The separate admin dashboard still uses phone OTP to protect customer orders and uploaded photos. If you want to use the admin dashboard, configure an SMS provider in Supabase Authentication → Sign In / Providers → Phone. This is not required for customer checkout.

## 4. Add your admin mobile number
1. Decide which mobile number will be used to sign in to the admin site. This is the number that receives the admin OTP (admin-only). It can be your personal/admin phone and does not have to be the WhatsApp receipt destination.
2. In Supabase **SQL Editor**, run this statement after replacing the example number with your full E.164 phone number:

```sql
insert into public.picnest_admins(phone)
values ('+919876543210')
on conflict (phone) do nothing;
```

3. The admin page checks this allowlist after admin OTP verification. A verified customer who is not in this table cannot open the dashboard.
4. Keep this table restricted. Never add a customer's phone number unless they should have full admin access.

## 5. Test before publishing
1. Open `index.html` from a local web server or your deployed site (not by double-clicking if browser security blocks requests).
2. On the customer site, enter your name, mobile number and delivery address. No customer OTP is required.
3. Add a product, upload a small test photo, add it to cart and place a test order.
4. The order is saved in Supabase. A WhatsApp message containing the order receipt opens to **+91 86818 01077** so you can send the customer your payment QR/details.
5. Open `admin.html` in a separate browser tab/window. Admin access still requires the allowlisted admin phone and an SMS OTP; then check that the order appears. Test changing its status and payment status.
6. Submit a test event enquiry and confirm it appears under Event enquiries in the admin dashboard.

## 6. Publish with GitHub Pages
1. Create or open your GitHub repository.
2. Upload `index.html` to the repository root. Upload `admin.html` to the same root. Keep both filenames exactly as shown.
3. In repository **Settings → Pages**, select **Deploy from a branch**, choose `main` and `/ (root)`, then Save.
4. Your customer site will be at `https://YOUR_GITHUB_USERNAME.github.io/YOUR_REPOSITORY/`.
5. Your separate admin site will be at `https://YOUR_GITHUB_USERNAME.github.io/YOUR_REPOSITORY/admin.html`.
6. Do not link the admin page prominently from the public storefront. Security is enforced by the Supabase admin allowlist and RLS, not by hiding the URL.

## Important notes before taking real payments
- The listed prices are starter prices carried forward from your previous PICNEST catalogue. Confirm your final production costs, delivery charges, event scope and prices before accepting paid orders.
- This starter does not collect online payments. It saves the order and opens a WhatsApp receipt to your admin number so you can share your QR/payment instructions manually.
- Customer photos are uploaded to a private bucket. Admins can open temporary signed photo links from the dashboard; those links expire after one hour.
- The reference product photos use externally hosted Unsplash image URLs. If a source image fails, the card displays a branded colour fallback instead of a broken-image icon. Replace these with your own product photographs when ready.
- Never paste a Supabase `service_role` key into HTML, GitHub, WhatsApp or any public place.
- Before launch, test guest order creation, photo upload, admin OTP access and WhatsApp on a second phone/device.
