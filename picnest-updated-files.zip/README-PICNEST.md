# PICNEST Updated Files & Admin Login Guide

## 1. How to Go to Admin Login & Sign In

1. Open your deployed admin URL in a browser:
   - `https://yuvanlokesh.github.io/Picnest/admin.html` (or `/picnest/admin.html` / local `admin.html`).
2. You will see the **Admin sign in** screen (email and password — phone OTP is no longer used).
3. Enter your **Admin email** and **Password**, then click **Sign in to dashboard**.
4. Make sure your account exists in **Supabase Authentication -> Users** and your email is added to the **`picnest_admins`** table in Supabase so your access is authorised.
5. To sign out when finished, click **Sign out** in the top-right header.

## 2. What Was Updated

- **`index.html` (Customer Website)**:
  - Live thumbnail previews when selecting photos, with a button to remove individual photos before adding to cart.
  - Pre-checkout **Order summary** displaying item quantity, photo count, notes, delivery details, and grand total.
  - Post-checkout **Order confirmation** modal showing Order ID, status, payment status, and a WhatsApp share link.
  - **Track order** modal to look up an order by Order ID and mobile number.
- **`admin.html` (Admin Dashboard)**:
  - Email + password login (`signInWithPassword`) verified against `picnest_admins`.
  - Summary cards for **Total orders**, **New orders**, **Pending payments**, and **Completed orders**.
  - Inline photo thumbnails from signed `picnest-photos` URLs and status controls (`New`, `Confirmed`, `Processing`, `Shipped`, `Delivered`, `Completed`, `Cancelled`).

## 3. Recommended Supabase SQL Helper for Customer Order Tracking

If Row Level Security (RLS) restricts direct `SELECT` on `picnest_orders` to authenticated admins, create a `SECURITY DEFINER` RPC function so customers can only look up a single order when both `id` and `customer_phone` match:

```sql
create or replace function public.track_picnest_order(p_order_id text, p_phone text)
returns table (
  id text,
  customer_name text,
  customer_phone text,
  delivery_address text,
  items jsonb,
  total numeric,
  status text,
  payment_status text,
  created_at timestamptz
)
language sql
security definer
set search_path = public
as $$
  select
    o.id,
    o.customer_name,
    o.customer_phone,
    o.delivery_address,
    o.items,
    o.total,
    o.status,
    o.payment_status,
    o.created_at
  from public.picnest_orders o
  where o.id = trim(p_order_id)
    and regexp_replace(o.customer_phone, '[^0-9]', '', 'g') = regexp_replace(p_phone, '[^0-9]', '', 'g')
  limit 1;
$$;

grant execute on function public.track_picnest_order(text, text) to anon, authenticated;
```
